# -*- coding: utf-8 -*-

from . import product_product
from . import slide_channel
from . import sale_order
