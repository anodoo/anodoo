# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import stock_change_standard_price
from . import stock_quantity_history
from . import stock_picking_return
