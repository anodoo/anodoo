# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import invite
from . import mail_compose_message
from . import mail_resend_cancel
from . import mail_resend_message
from . import email_template_preview
from . import base_module_uninstall
from . import base_partner_merge
