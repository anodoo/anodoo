# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_attachment
from . import ir_http
from . import res_partner
from . import mail_message
from . import calendar
from . import mail_activity
from . import res_users
