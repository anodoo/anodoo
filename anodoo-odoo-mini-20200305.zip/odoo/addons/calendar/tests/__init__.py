# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_calendar
from . import test_calendar_recurrent_event_case2
