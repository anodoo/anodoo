# -*- coding: utf-8 -*-

from . import crm_lead_lost
from . import crm_merge_opportunities
from . import crm_lead_to_opportunity