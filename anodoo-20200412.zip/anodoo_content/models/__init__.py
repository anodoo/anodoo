# -*- coding: utf-8 -*-

from . import content_models
from . import res_config_settings