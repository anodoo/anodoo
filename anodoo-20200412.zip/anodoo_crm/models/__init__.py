# -*- coding: utf-8 -*-

from . import crm_models
from . import res_config_settings