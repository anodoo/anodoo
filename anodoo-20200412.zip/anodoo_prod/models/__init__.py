# -*- coding: utf-8 -*-

from . import prod_models
from . import product_pricelist
from . import promotion_models
from . import res_config_settings