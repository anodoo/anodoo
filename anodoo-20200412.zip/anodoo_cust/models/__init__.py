# -*- coding: utf-8 -*-

from . import customer_info
from . import customer_lifetime
from . import customer_segment
from . import customer_pool
from . import customer_user
from . import res_config_settings