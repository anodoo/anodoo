# -*- coding: utf-8 -*-

from . import team_models
from . import crm_team
from . import res_config_settings
from . import note
