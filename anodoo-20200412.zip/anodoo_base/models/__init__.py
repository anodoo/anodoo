# -*- coding: utf-8 -*-

from . import base_models
from . import res_country
from . import res_config_settings
from . import ir_translation
from . import res_partner
from . import ir_ui_menu
from . import auth_oauth
from . import res_users
from . import res_lang